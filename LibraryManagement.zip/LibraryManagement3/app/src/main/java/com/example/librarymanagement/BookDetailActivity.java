package com.example.librarymanagement;

import android.os.Bundle;
import android.widget.EditText;
import android.widget.Button;
import androidx.appcompat.app.AppCompatActivity;
import android.widget.Toast;
import android.content.Intent;


public class BookDetailActivity extends AppCompatActivity {
    EditText etTitle, etAuthor, etCategory, etQuantity;
    Button btnUpdate, btnDelete;
    DatabaseHelper dbHelper;
    int bookId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_book_detail);

        etTitle = findViewById(R.id.etTitle);
        etAuthor = findViewById(R.id.etAuthor);
        etCategory = findViewById(R.id.etCategory);
        etQuantity = findViewById(R.id.etQuantity);
        btnUpdate = findViewById(R.id.btnUpdate);
        btnDelete = findViewById(R.id.btnDelete);

        dbHelper = new DatabaseHelper(this);

        // Nhận dữ liệu từ Intent
        bookId = getIntent().getIntExtra("book_id", -1);
        etTitle.setText(getIntent().getStringExtra("title"));
        etAuthor.setText(getIntent().getStringExtra("author"));
        etCategory.setText(getIntent().getStringExtra("category"));
        etQuantity.setText(String.valueOf(getIntent().getIntExtra("quantity", 0)));

        // Cập nhật sách
        btnUpdate.setOnClickListener(v -> {
            String newTitle = etTitle.getText().toString().trim();
            String newAuthor = etAuthor.getText().toString().trim();
            String newCategory = etCategory.getText().toString().trim();
            int newQuantity = Integer.parseInt(etQuantity.getText().toString().trim());

            boolean success = dbHelper.updateBook(bookId, newTitle, newAuthor, newCategory, newQuantity);
            if (success) {
                Toast.makeText(this, "Cập nhật thành công!", Toast.LENGTH_SHORT).show();
                finish();
            } else {
                Toast.makeText(this, "Cập nhật thất bại!", Toast.LENGTH_SHORT).show();
            }
        });

        // Xóa sách
        btnDelete.setOnClickListener(v -> {
            boolean success = dbHelper.deleteBook(bookId);
            if (success) {
                Toast.makeText(this, "Xóa thành công!", Toast.LENGTH_SHORT).show();
                finish();
            } else {
                Toast.makeText(this, "Xóa thất bại!", Toast.LENGTH_SHORT).show();
            }
        });
    }

}
