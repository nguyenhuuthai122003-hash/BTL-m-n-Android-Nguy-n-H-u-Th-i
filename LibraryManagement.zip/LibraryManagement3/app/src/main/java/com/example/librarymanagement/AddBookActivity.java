package com.example.librarymanagement;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;

public class AddBookActivity extends AppCompatActivity {
    EditText etTitle, etAuthor, etCategory, etQuantity;
    Button btnAddBook;
    DatabaseHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_book);

        etTitle = findViewById(R.id.etTitle);
        etAuthor = findViewById(R.id.etAuthor);
        etCategory = findViewById(R.id.etCategory);
        etQuantity = findViewById(R.id.etQuantity);
        btnAddBook = findViewById(R.id.btnAddBook);

        dbHelper = new DatabaseHelper(this);

        btnAddBook.setOnClickListener(v -> {
            String title = etTitle.getText().toString().trim();
            String author = etAuthor.getText().toString().trim();
            String category = etCategory.getText().toString().trim();
            String quantityStr = etQuantity.getText().toString().trim();

            if (title.isEmpty() || author.isEmpty() || category.isEmpty() || quantityStr.isEmpty()) {
                Toast.makeText(this, "Vui lòng nhập đầy đủ thông tin!", Toast.LENGTH_SHORT).show();
                return;
            }

            int quantity;
            try {
                quantity = Integer.parseInt(quantityStr);
            } catch (NumberFormatException e) {
                Toast.makeText(this, "Số lượng phải là số!", Toast.LENGTH_SHORT).show();
                return;
            }

            boolean success = dbHelper.addBook(title, author, category, quantity);

            if (success) {
                Toast.makeText(this, "Thêm sách thành công!", Toast.LENGTH_SHORT).show();
                startActivity(new Intent(this, BookListActivity.class));
                finish();
            } else {
                Toast.makeText(this, "Thêm sách thất bại!", Toast.LENGTH_SHORT).show();
            }
        });

    }
}
