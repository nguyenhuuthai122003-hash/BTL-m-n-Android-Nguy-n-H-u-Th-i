package com.example.librarymanagement;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;

public class BorrowAdapter extends RecyclerView.Adapter<BorrowAdapter.BorrowViewHolder> {
    private List<BorrowRecord> borrowList;

    public BorrowAdapter(List<BorrowRecord> borrowList) {
        this.borrowList = borrowList;
    }

    @NonNull
    @Override
    public BorrowViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(android.R.layout.simple_list_item_2, parent, false);
        return new BorrowViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull BorrowViewHolder holder, int position) {
        BorrowRecord record = borrowList.get(position);
        holder.line1.setText("User ID: " + record.getUserId() + " - Book ID: " + record.getBookId());
        holder.line2.setText("Trạng thái: " + record.getStatus());


    }

    @Override
    public int getItemCount() {
        return borrowList.size();
    }

    static class BorrowViewHolder extends RecyclerView.ViewHolder {
        TextView line1, line2;

        public BorrowViewHolder(@NonNull View itemView) {
            super(itemView);
            line1 = itemView.findViewById(android.R.id.text1);
            line2 = itemView.findViewById(android.R.id.text2);
        }
    }
}
