package com.example.librarymanagement;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

public class DatabaseHelper extends SQLiteOpenHelper {
    private static final String DATABASE_NAME = "aaaa.db"; // tên file .db trong assets
    private static final int DATABASE_VERSION = 1;
    private Context context;

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
        this.context = context;

        copyDatabase();
        // copy DB từ assets

    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        // Không cần tạo bảng vì file btl.db đã có sẵn trong assets
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // Nếu cần nâng cấp DB, xử lý tại đây
    }

    // Copy database từ assets sang thư mục databases
    private void copyDatabase() {
        String dbPath = context.getDatabasePath(DATABASE_NAME).getPath();
        File dbFile = new File(dbPath);

        if (!dbFile.exists()) {
            dbFile.getParentFile().mkdirs(); // tạo thư mục nếu chưa có
            try (InputStream is = context.getAssets().open(DATABASE_NAME);
                 OutputStream os = new FileOutputStream(dbPath)) {

                byte[] buffer = new byte[1024];
                int length;
                while ((length = is.read(buffer)) > 0) {
                    os.write(buffer, 0, length);
                }
                os.flush();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    // ================== Các hàm CRUD ==================

    // Thêm người dùng mới
    public boolean addUser(String name, String email, String password, String role) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("name", name);
        values.put("email", email);
        values.put("password", password);
        values.put("role", role);

        long result = db.insert("Users", null, values);
        db.close();
        return result != -1;
    }

    // Kiểm tra đăng nhập
    public boolean checkLogin(String email, String password) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM Users WHERE email=? AND password=?", new String[]{email, password});
        boolean result = cursor.getCount() > 0;
        cursor.close();
        db.close();
        return result;
    }

    // Kiểm tra email đã tồn tại chưa
    public boolean checkUserExists(String email) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM Users WHERE email=?", new String[]{email});
        boolean exists = cursor.getCount() > 0;
        cursor.close();
        db.close();
        return exists;
    }

    // Lấy toàn bộ sách
    public Cursor getAllBooks() {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.rawQuery("SELECT * FROM Books", null);
    }

    // Thêm sách mới
    public boolean addBook(String title, String author, String category, int quantity) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("title", title);
        values.put("author", author);
        values.put("category", category);
        values.put("quantity", quantity);

        long result = db.insert("Books", null, values);
        db.close();
        return result != -1;
    }

    // Cập nhật sách
    public boolean updateBook(int id, String title, String author, String category, int quantity) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("title", title);
        values.put("author", author);
        values.put("category", category);
        values.put("quantity", quantity);

        int rows = db.update("Books", values, "id=?", new String[]{String.valueOf(id)});
        db.close();
        return rows > 0;
    }

    // Xóa sách
    public boolean deleteBook(int id) {
        SQLiteDatabase db = this.getWritableDatabase();
        int rows = db.delete("Books", "id=?", new String[]{String.valueOf(id)});
        db.close();
        return rows > 0;
    }

    // Ghi nhận mượn sách
    public boolean borrowBook(int userId, int bookId, String borrowDate, String returnDate) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("user_id", userId);
        values.put("book_id", bookId);
        values.put("borrow_date", borrowDate);
        values.put("return_date", returnDate);
        values.put("status", "borrowed");

        long result = db.insert("BorrowRecords", null, values);

        // Giảm số lượng sách
        db.execSQL("UPDATE Books SET quantity = quantity - 1 WHERE id=" + bookId);

        db.close();
        return result != -1;
    }

    // Trả sách
    public boolean returnBook(int recordId, int bookId) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("status", "returned");

        int rows = db.update("BorrowRecords", values, "id=?", new String[]{String.valueOf(recordId)});

        // Tăng số lượng sách
        db.execSQL("UPDATE Books SET quantity = quantity + 1 WHERE id=" + bookId);

        db.close();
        return rows > 0;
    }

    // Lấy danh sách mượn trả
    public Cursor getAllBorrowRecords() {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.rawQuery("SELECT * FROM BorrowRecords", null);
    }

    // Tổng số sách
    public int getTotalBooks() {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT SUM(quantity) FROM Books", null);
        int total = 0;
        if (cursor.moveToFirst()) {
            total = cursor.getInt(0);
        }
        cursor.close();
        db.close();
        return total;
    }

    // Sách đang mượn
    public int getBorrowedBooks() {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT COUNT(*) FROM BorrowRecords WHERE status='borrowed'", null);
        int borrowed = 0;
        if (cursor.moveToFirst()) {
            borrowed = cursor.getInt(0);
        }
        cursor.close();
        db.close();
        return borrowed;
    }

    // Sách quá hạn
    public int getOverdueBooks(String currentDate) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT COUNT(*) FROM BorrowRecords WHERE status='borrowed' AND return_date < ?", new String[]{currentDate});
        int overdue = 0;
        if (cursor.moveToFirst()) {
            overdue = cursor.getInt(0);
        }
        cursor.close();
        db.close();
        return overdue;
    }
}







