package com.example.librarymanagement;

import android.os.Bundle;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class StatisticsActivity extends AppCompatActivity {
    TextView tvTotalBooks, tvBorrowedBooks, tvOverdueBooks;
    DatabaseHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_statistics);

        tvTotalBooks = findViewById(R.id.tvTotalBooks);
        tvBorrowedBooks = findViewById(R.id.tvBorrowedBooks);
        tvOverdueBooks = findViewById(R.id.tvOverdueBooks);

        dbHelper = new DatabaseHelper(this);

        // Lấy ngày hiện tại
        String currentDate = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
                .format(new Date());

        // Hiển thị thống kê
        int totalBooks = dbHelper.getTotalBooks();
        int borrowedBooks = dbHelper.getBorrowedBooks();
        int overdueBooks = dbHelper.getOverdueBooks(currentDate);

        tvTotalBooks.setText("Tổng số sách: " + totalBooks);
        tvBorrowedBooks.setText("Sách đang mượn: " + borrowedBooks);
        tvOverdueBooks.setText("Sách quá hạn: " + overdueBooks);
    }
}
