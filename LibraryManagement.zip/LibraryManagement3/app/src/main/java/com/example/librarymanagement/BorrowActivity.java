package com.example.librarymanagement;

import android.database.Cursor;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;
import java.util.List;

public class BorrowActivity extends AppCompatActivity {
    RecyclerView recyclerBorrowRecords;
    DatabaseHelper dbHelper;
    List<BorrowRecord> borrowList;
    BorrowAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_borrow);

        recyclerBorrowRecords = findViewById(R.id.recyclerBorrowRecords);
        recyclerBorrowRecords.setLayoutManager(new LinearLayoutManager(this));

        dbHelper = new DatabaseHelper(this);
        borrowList = new ArrayList<>();

        Cursor cursor = dbHelper.getAllBorrowRecords();
        if (cursor.moveToFirst()) {
            do {
                int id = cursor.getInt(cursor.getColumnIndexOrThrow("id"));
                int userId = cursor.getInt(cursor.getColumnIndexOrThrow("user_id"));
                int bookId = cursor.getInt(cursor.getColumnIndexOrThrow("book_id"));
                String borrowDate = cursor.getString(cursor.getColumnIndexOrThrow("borrow_date"));
                String returnDate = cursor.getString(cursor.getColumnIndexOrThrow("return_date"));
                String status = cursor.getString(cursor.getColumnIndexOrThrow("status"));

                borrowList.add(new BorrowRecord(id, userId, bookId, borrowDate, returnDate, status));
            } while (cursor.moveToNext());
        }
        cursor.close();

        adapter = new BorrowAdapter(borrowList);
        recyclerBorrowRecords.setAdapter(adapter);
    }
}
