package com.example.librarymanagement;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import androidx.appcompat.app.AppCompatActivity;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.util.Log;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        DatabaseHelper dbHelper = new DatabaseHelper(this);
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        Cursor c = db.rawQuery("SELECT name FROM sqlite_master WHERE type='table'", null);
        while (c.moveToNext()) {
            Log.d("DB_TABLE", "Table: " + c.getString(0));
        }
        c.close();
        db.close();

        Button btnAddBook = findViewById(R.id.btnAddBook);
        Button btnBookList = findViewById(R.id.btnBookList);
        Button btnBorrow = findViewById(R.id.btnBorrow);
        Button btnStatistics = findViewById(R.id.btnStatistics);

        btnAddBook.setOnClickListener(v -> {
            startActivity(new Intent(MainActivity.this, AddBookActivity.class));
        });

        btnBookList.setOnClickListener(v -> {
            startActivity(new Intent(MainActivity.this, BookListActivity.class));
        });

        btnBorrow.setOnClickListener(v -> {
            startActivity(new Intent(MainActivity.this, BorrowActivity.class));
        });

        btnStatistics.setOnClickListener(v -> {
            startActivity(new Intent(MainActivity.this, StatisticsActivity.class));
        });
    }
}
