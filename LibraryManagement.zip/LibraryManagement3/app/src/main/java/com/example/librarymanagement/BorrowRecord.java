package com.example.librarymanagement;

public class BorrowRecord {
    private int id;
    private int userId;
    private int bookId;
    private String borrowDate;
    private String returnDate;
    private String status;

    public BorrowRecord(int id, int userId, int bookId, String borrowDate, String returnDate, String status) {
        this.id = id;
        this.userId = userId;
        this.bookId = bookId;
        this.borrowDate = borrowDate;
        this.returnDate = returnDate;
        this.status = status;
    }

    public int getId() { return id; }
    public int getUserId() { return userId; }
    public int getBookId() { return bookId; }
    public String getBorrowDate() { return borrowDate; }
    public String getReturnDate() { return returnDate; }
    public String getStatus() { return status; }
}
